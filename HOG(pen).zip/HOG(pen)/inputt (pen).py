# -*- coding: utf-8 -*-
"""
Created on Tue Feb  7 21:34:18 2023

@author: admin
"""

import cv2
from skimage.feature import hog

# Load the image
img = cv2.imread('download.jpg')

# Convert the image to grayscale
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# Calculate the HOG features of the image
fd, hog_image = hog(gray, orientations=8, pixels_per_cell=(16, 16),cells_per_block=(1, 1), visualize=True, multichannel=False)

# Apply a threshold to the HOG image to get a binary image
threshold_value = 0.5
binary_image = hog_image > threshold_value

# Find contours in the binary image
contours, hierarchy = cv2.findContours(binary_image.astype('uint8'), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

# Draw the contours on the original image
cv2.drawContours(img, contours, -1, (0, 255, 0), 2)

# Display the original image with detected contours
cv2.imshow('Pen detection', img)
cv2.waitKey(0)
cv2.destroyAllWindows()

