# -*- coding: utf-8 -*-
"""
Created on Tue Feb  7 21:47:05 2023

@author: admin
"""

import cv2
import numpy as np

pen_classifier = cv2.HOGDescriptor()
pen_classifier.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())


cap = cv2.VideoCapture(0)

while True:
   
    ret, frame = cap.read()
    
  
    gray = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)

   
    boxes, weights = pen_classifier.detectMultiScale(gray, winStride=(8,8), padding=(32,32), scale=1.05)

   
    for (x, y, w, h) in boxes:
        cv2.rectangle(frame, (x,y), (x+w,y+h), (0,0,255), 2)

   
    cv2.imshow("Pen Detection", frame)
    
   
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break


cap.release()
cv2.destroyAllWindows()

