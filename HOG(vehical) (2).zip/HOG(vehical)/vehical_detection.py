#!/usr/bin/env python
# coding: utf-8

# In[11]:


import cv2
import numpy as np


# In[12]:


car_classifier = cv2.CascadeClassifier('cars.xml')


# In[ ]:





# In[9]:


import cv2
import numpy as np

car_classifier = cv2.CascadeClassifier('cars.xml')

img = cv2.imread('image1.jpg')

#grayscale
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# Detection
cars = car_classifier.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=3, minSize=(30, 30))

for (x, y, w, h) in cars:
    cv2.rectangle(img, (x,y), (x+w, y+h), (0, 0, 255), 2)

cv2.imshow("Car Detection", img)
cv2.waitKey(0)
cv2.destroyAllWindows()


# In[ ]:





# In[5]:


def calculate_accuracy(gt, pred):
    tp = 0
    fp = 0
    fn = 0
    for gt_box in gt:
        for pred_box in pred:
            if overlap(gt_box, pred_box) >= 0.5:
                tp += 1
                pred.remove(pred_box)
                break
        else:
            fn += 1
    fp = len(pred)
    accuracy = tp / (tp + fp + fn)
    return accuracy

def overlap(box1, box2):
    x1, y1, w1, h1 = box1
    x2, y2, w2, h2 = box2
    x_overlap = max(0, min(x1 + w1, x2 + w2) - max(x1, x2))
    y_overlap = max(0, min(y1 + h1, y2 + h2) - max(y1, y2))
    overlap_area = x_overlap * y_overlap
    box1_area = w1 * h1
    box2_area = w2 * h2
    union_area = box1_area + box2_area - overlap_area
    return overlap_area / union_area

gt = [(10, 20, 30, 40), (50, 60, 70, 80)]
pred = [(15, 25, 35, 45), (55, 65, 75, 85), (95, 105, 115, 125)]

accuracy = calculate_accuracy(gt, pred)
print("Accuracy:", accuracy)


# In[ ]:


#below is live detection


# In[6]:


import cv2
import numpy as np

car_classifier = cv2.CascadeClassifier('cars.xml')

cap = cv2.VideoCapture(0)

while True:
    
    ret, frame = cap.read()
    
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    cars = car_classifier.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=3, minSize=(30, 30))
  
    for (x, y, w, h) in cars:
        cv2.rectangle(frame, (x,y), (x+w, y+h), (0, 0, 255), 2)

    cv2.imshow("Car Detection", frame)
    
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()


# In[ ]:


import cv2

# Load the HOG face detector
vehical_detector = cv2.CascadeClassifier('cars.xml')

# Open the video capture
cap = cv2.VideoCapture(0)

while True:
    # Read a frame from the video capture
    ret, frame = cap.read()

    # Convert the frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Detect faces in the grayscale frame
    faces = vehical_detector.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)

    # Draw rectangles around the faces
    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)

    # Display the resulting frame
    cv2.imshow('Vehical Detection', frame)

    # Break the loop if the 'q' key is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video capture and destroy the windows
cap.release()
cv2.destroyAllWindows()


# In[2]:


#vedio input


# In[ ]:


import cv2
import time

# Load the HOG vehicle detector
vehicle_detector = cv2.HOGDescriptor()
vehicle_detector.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

# Open the video capture
cap = cv2.VideoCapture("vehicles.mp4")

while True:
    start_time = time.time()

    # Read a frame from the video capture
    ret, frame = cap.read()

    # Break the loop if the video has ended
    if not ret:
        break

    # Resize the frame for faster processing
    frame = cv2.resize(frame, (640, 360))

    # Detect vehicles in the frame
    boxes, weights = vehicle_detector.detectMultiScale(frame, winStride=(8, 8), padding=(32, 32), scale=1.05)

    # Draw rectangles around the vehicles
    for (x, y, w, h) in boxes:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)

    # Display the resulting frame
    cv2.imshow('Vehicle Detection', frame)

    # Break the loop if the 'q' key is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

    print("Time taken by the frame: {:.2f} sec".format(time.time() - start_time))

# Release the video capture and destroy the windows
cap.release()
cv2.destroyAllWindows()

